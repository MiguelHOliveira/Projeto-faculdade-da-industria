==SEGUNDA PROVA DA MATÉRIA WEB FRONT END==

Aluno: Miguel Henrique de Oliveira Rosa

LInk do repositório: https://github.com/xXMiguelitoXx/Projeto-faculdade-da-industria

Como utilizar:

    1. Dentro da pasta "/API-FI-Back-MH/client" executar o comando "npm install"
    2. Em seguida executar o comando "npm start"
    3. Na pasta "/API-FI-Back-MH/server" executar o comando "npm install"
    4.  Em seguida executar o comando "npm install"
    5. Por último, executar "npm run devStart"